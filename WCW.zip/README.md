# WordCloud for Wedding

基于[wordcloud2.js](https://github.com/timdream/wordcloud2.js)和[b2wordcloud](https://github.com/holanlan/b2wordcloud)
